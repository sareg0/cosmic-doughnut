import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/HomeView.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=bc0fccca";
import TheWelcome from "/src/components/TheWelcome.vue";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "HomeView",
  setup(__props, { expose: __expose }) {
    __expose();
    const __returned__ = { TheWelcome };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=bc0fccca";
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return _openBlock(), _createElementBlock("main", null, [
    _createVNode($setup["TheWelcome"])
  ]);
}
_sfc_main.__hmrId = "b4e148ca";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Users/sararegan/Code/cosmic-doughnut/src/views/HomeView.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLE9BQU8sZ0JBQWdCOzs7Ozs7Ozs7Ozs7dUJBSXJCLG9CQUVPO0FBQUEsSUFETCxhQUFjO0FBQUEiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSG9tZVZpZXcudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XG5pbXBvcnQgVGhlV2VsY29tZSBmcm9tIFwiLi4vY29tcG9uZW50cy9UaGVXZWxjb21lLnZ1ZVwiO1xuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cbiAgPG1haW4+XG4gICAgPFRoZVdlbGNvbWUgLz5cbiAgPC9tYWluPlxuPC90ZW1wbGF0ZT5cbiJdLCJmaWxlIjoiL1VzZXJzL3NhcmFyZWdhbi9Db2RlL2Nvc21pYy1kb3VnaG51dC9zcmMvdmlld3MvSG9tZVZpZXcudnVlIn0=