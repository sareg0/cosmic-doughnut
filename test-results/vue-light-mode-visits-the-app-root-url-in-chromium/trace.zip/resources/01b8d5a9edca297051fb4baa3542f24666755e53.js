import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/WelcomeItem.vue");const _sfc_main = {}
import { renderSlot as _renderSlot, createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, pushScopeId as _pushScopeId, popScopeId as _popScopeId } from "/node_modules/.vite/deps/vue.js?v=bc0fccca"

const _withScopeId = n => (_pushScopeId("data-v-bd9b3c35"),n=n(),_popScopeId(),n)
const _hoisted_1 = { class: "item" }
const _hoisted_2 = { class: "details" }

function _sfc_render(_ctx, _cache) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createElementVNode("i", null, [
      _renderSlot(_ctx.$slots, "icon", {}, undefined, true)
    ]),
    _createElementVNode("div", _hoisted_2, [
      _createElementVNode("h3", null, [
        _renderSlot(_ctx.$slots, "heading", {}, undefined, true)
      ]),
      _renderSlot(_ctx.$slots, "default", {}, undefined, true)
    ])
  ]))
}

import "/src/components/WelcomeItem.vue?vue&type=style&index=0&scoped=bd9b3c35&lang.css"

_sfc_main.__hmrId = "bd9b3c35"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-bd9b3c35"],['__file',"/Users/sararegan/Code/cosmic-doughnut/src/components/WelcomeItem.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIldlbGNvbWVJdGVtLnZ1ZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7cUJBQ08sS0FBSyxFQUFDLE1BQU07cUJBSVYsS0FBSyxFQUFDLFNBQVM7Ozt3QkFKdEIsb0JBVU0sT0FWTixVQVVNO0lBVEosb0JBRUk7TUFERixZQUF5Qjs7SUFFM0Isb0JBS00sT0FMTixVQUtNO01BSkosb0JBRUs7UUFESCxZQUE0Qjs7TUFFOUIsWUFBYSIsImZpbGUiOiIvVXNlcnMvc2FyYXJlZ2FuL0NvZGUvY29zbWljLWRvdWdobnV0L3NyYy9jb21wb25lbnRzL1dlbGNvbWVJdGVtLnZ1ZSIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJpdGVtXCI+XG4gICAgPGk+XG4gICAgICA8c2xvdCBuYW1lPVwiaWNvblwiPjwvc2xvdD5cbiAgICA8L2k+XG4gICAgPGRpdiBjbGFzcz1cImRldGFpbHNcIj5cbiAgICAgIDxoMz5cbiAgICAgICAgPHNsb3QgbmFtZT1cImhlYWRpbmdcIj48L3Nsb3Q+XG4gICAgICA8L2gzPlxuICAgICAgPHNsb3Q+PC9zbG90PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzdHlsZSBzY29wZWQ+XG4uaXRlbSB7XG4gIG1hcmdpbi10b3A6IDJyZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmRldGFpbHMge1xuICBmbGV4OiAxO1xuICBtYXJnaW4tbGVmdDogMXJlbTtcbn1cblxuaSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHBsYWNlLWl0ZW1zOiBjZW50ZXI7XG4gIHBsYWNlLWNvbnRlbnQ6IGNlbnRlcjtcbiAgd2lkdGg6IDMycHg7XG4gIGhlaWdodDogMzJweDtcblxuICBjb2xvcjogdmFyKC0tY29sb3ItdGV4dCk7XG59XG5cbmgzIHtcbiAgZm9udC1zaXplOiAxLjJyZW07XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIG1hcmdpbi1ib3R0b206IDAuNHJlbTtcbiAgY29sb3I6IHZhcigtLWNvbG9yLWhlYWRpbmcpO1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogMTAyNHB4KSB7XG4gIC5pdGVtIHtcbiAgICBtYXJnaW4tdG9wOiAwO1xuICAgIHBhZGRpbmc6IDAuNHJlbSAwIDFyZW0gY2FsYyh2YXIoLS1zZWN0aW9uLWdhcCkgLyAyKTtcbiAgfVxuXG4gIGkge1xuICAgIHRvcDogY2FsYyg1MCUgLSAyNXB4KTtcbiAgICBsZWZ0OiAtMjZweDtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tY29sb3ItYm9yZGVyKTtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1jb2xvci1iYWNrZ3JvdW5kKTtcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgd2lkdGg6IDUwcHg7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICB9XG5cbiAgLml0ZW06YmVmb3JlIHtcbiAgICBjb250ZW50OiBcIiBcIjtcbiAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkIHZhcigtLWNvbG9yLWJvcmRlcik7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDA7XG4gICAgYm90dG9tOiBjYWxjKDUwJSArIDI1cHgpO1xuICAgIGhlaWdodDogY2FsYyg1MCUgLSAyNXB4KTtcbiAgfVxuXG4gIC5pdGVtOmFmdGVyIHtcbiAgICBjb250ZW50OiBcIiBcIjtcbiAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkIHZhcigtLWNvbG9yLWJvcmRlcik7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDA7XG4gICAgdG9wOiBjYWxjKDUwJSArIDI1cHgpO1xuICAgIGhlaWdodDogY2FsYyg1MCUgLSAyNXB4KTtcbiAgfVxuXG4gIC5pdGVtOmZpcnN0LW9mLXR5cGU6YmVmb3JlIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG5cbiAgLml0ZW06bGFzdC1vZi10eXBlOmFmdGVyIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG59XG48L3N0eWxlPlxuIl19