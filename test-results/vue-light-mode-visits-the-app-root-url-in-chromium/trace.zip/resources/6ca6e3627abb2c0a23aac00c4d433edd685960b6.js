import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TheWelcome.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=bc0fccca";
import WelcomeItem from "/src/components/WelcomeItem.vue";
import DocumentationIcon from "/src/components/icons/IconDocumentation.vue";
import ToolingIcon from "/src/components/icons/IconTooling.vue";
import EcosystemIcon from "/src/components/icons/IconEcosystem.vue";
import CommunityIcon from "/src/components/icons/IconCommunity.vue";
import SupportIcon from "/src/components/icons/IconSupport.vue";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "TheWelcome",
  setup(__props, { expose: __expose }) {
    __expose();
    const __returned__ = { WelcomeItem, DocumentationIcon, ToolingIcon, EcosystemIcon, CommunityIcon, SupportIcon };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { createVNode as _createVNode, createTextVNode as _createTextVNode, createElementVNode as _createElementVNode, withCtx as _withCtx, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=bc0fccca";
const _hoisted_1 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://vuejs.org/",
    target: "_blank",
    rel: "noopener"
  },
  "official documentation",
  -1
  /* HOISTED */
);
const _hoisted_2 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://vitejs.dev/guide/features.html",
    target: "_blank",
    rel: "noopener"
  },
  "Vite",
  -1
  /* HOISTED */
);
const _hoisted_3 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://code.visualstudio.com/",
    target: "_blank",
    rel: "noopener"
  },
  "VSCode",
  -1
  /* HOISTED */
);
const _hoisted_4 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://github.com/johnsoncodehk/volar",
    target: "_blank",
    rel: "noopener"
  },
  "Volar",
  -1
  /* HOISTED */
);
const _hoisted_5 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://www.cypress.io/",
    target: "_blank",
    rel: "noopener"
  },
  "Cypress",
  -1
  /* HOISTED */
);
const _hoisted_6 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://on.cypress.io/component",
    target: "_blank",
    rel: "noopener"
  },
  "Cypress Component Testing",
  -1
  /* HOISTED */
);
const _hoisted_7 = /* @__PURE__ */ _createElementVNode(
  "br",
  null,
  null,
  -1
  /* HOISTED */
);
const _hoisted_8 = /* @__PURE__ */ _createElementVNode(
  "code",
  null,
  "README.md",
  -1
  /* HOISTED */
);
const _hoisted_9 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://pinia.vuejs.org/",
    target: "_blank",
    rel: "noopener"
  },
  "Pinia",
  -1
  /* HOISTED */
);
const _hoisted_10 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://router.vuejs.org/",
    target: "_blank",
    rel: "noopener"
  },
  "Vue Router",
  -1
  /* HOISTED */
);
const _hoisted_11 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://test-utils.vuejs.org/",
    target: "_blank",
    rel: "noopener"
  },
  "Vue Test Utils",
  -1
  /* HOISTED */
);
const _hoisted_12 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://github.com/vuejs/devtools",
    target: "_blank",
    rel: "noopener"
  },
  "Vue Dev Tools",
  -1
  /* HOISTED */
);
const _hoisted_13 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://github.com/vuejs/awesome-vue",
    target: "_blank",
    rel: "noopener"
  },
  "Awesome Vue",
  -1
  /* HOISTED */
);
const _hoisted_14 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://chat.vuejs.org",
    target: "_blank",
    rel: "noopener"
  },
  "Vue Land",
  -1
  /* HOISTED */
);
const _hoisted_15 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://stackoverflow.com/questions/tagged/vue.js",
    target: "_blank",
    rel: "noopener"
  },
  "StackOverflow",
  -1
  /* HOISTED */
);
const _hoisted_16 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://news.vuejs.org",
    target: "_blank",
    rel: "noopener"
  },
  "our mailing list",
  -1
  /* HOISTED */
);
const _hoisted_17 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://twitter.com/vuejs",
    target: "_blank",
    rel: "noopener"
  },
  "@vuejs",
  -1
  /* HOISTED */
);
const _hoisted_18 = /* @__PURE__ */ _createElementVNode(
  "a",
  {
    href: "https://vuejs.org/sponsor/",
    target: "_blank",
    rel: "noopener"
  },
  "becoming a sponsor",
  -1
  /* HOISTED */
);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return _openBlock(), _createElementBlock(
    _Fragment,
    null,
    [
      _createVNode($setup["WelcomeItem"], null, {
        icon: _withCtx(() => [
          _createVNode($setup["DocumentationIcon"])
        ]),
        heading: _withCtx(() => [
          _createTextVNode("Documentation")
        ]),
        default: _withCtx(() => [
          _createTextVNode(" Vue\u2019s "),
          _hoisted_1,
          _createTextVNode(" provides you with all information you need to get started. ")
        ]),
        _: 1
        /* STABLE */
      }),
      _createVNode($setup["WelcomeItem"], null, {
        icon: _withCtx(() => [
          _createVNode($setup["ToolingIcon"])
        ]),
        heading: _withCtx(() => [
          _createTextVNode("Tooling")
        ]),
        default: _withCtx(() => [
          _createTextVNode(" This project is served and bundled with "),
          _hoisted_2,
          _createTextVNode(". The recommended IDE setup is "),
          _hoisted_3,
          _createTextVNode(" + "),
          _hoisted_4,
          _createTextVNode(". If you need to test your components and web pages, check out "),
          _hoisted_5,
          _createTextVNode(" and "),
          _hoisted_6,
          _createTextVNode(". "),
          _hoisted_7,
          _createTextVNode(" More instructions are available in "),
          _hoisted_8,
          _createTextVNode(". ")
        ]),
        _: 1
        /* STABLE */
      }),
      _createVNode($setup["WelcomeItem"], null, {
        icon: _withCtx(() => [
          _createVNode($setup["EcosystemIcon"])
        ]),
        heading: _withCtx(() => [
          _createTextVNode("Ecosystem")
        ]),
        default: _withCtx(() => [
          _createTextVNode(" Get official tools and libraries for your project: "),
          _hoisted_9,
          _createTextVNode(", "),
          _hoisted_10,
          _createTextVNode(", "),
          _hoisted_11,
          _createTextVNode(", and "),
          _hoisted_12,
          _createTextVNode(". If you need more resources, we suggest paying "),
          _hoisted_13,
          _createTextVNode(" a visit. ")
        ]),
        _: 1
        /* STABLE */
      }),
      _createVNode($setup["WelcomeItem"], null, {
        icon: _withCtx(() => [
          _createVNode($setup["CommunityIcon"])
        ]),
        heading: _withCtx(() => [
          _createTextVNode("Community")
        ]),
        default: _withCtx(() => [
          _createTextVNode(" Got stuck? Ask your question on "),
          _hoisted_14,
          _createTextVNode(", our official Discord server, or "),
          _hoisted_15,
          _createTextVNode(". You should also subscribe to "),
          _hoisted_16,
          _createTextVNode(" and follow the official "),
          _hoisted_17,
          _createTextVNode(" twitter account for latest news in the Vue world. ")
        ]),
        _: 1
        /* STABLE */
      }),
      _createVNode($setup["WelcomeItem"], null, {
        icon: _withCtx(() => [
          _createVNode($setup["SupportIcon"])
        ]),
        heading: _withCtx(() => [
          _createTextVNode("Support Vue")
        ]),
        default: _withCtx(() => [
          _createTextVNode(" As an independent project, Vue relies on community backing for its sustainability. You can help us by "),
          _hoisted_18,
          _createTextVNode(". ")
        ]),
        _: 1
        /* STABLE */
      })
    ],
    64
    /* STABLE_FRAGMENT */
  );
}
_sfc_main.__hmrId = "14d3142e";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Users/sararegan/Code/cosmic-doughnut/src/components/TheWelcome.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sdUJBQXVCO0FBQzlCLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sbUJBQW1CO0FBQzFCLE9BQU8sbUJBQW1CO0FBQzFCLE9BQU8saUJBQWlCOzs7Ozs7Ozs7OzttQkFXcEI7QUFBQSxFQUVDO0FBQUE7QUFBQSxJQUZFLE1BQUs7QUFBQSxJQUFxQixRQUFPO0FBQUEsSUFBUyxLQUFJO0FBQUE7RUFDOUM7QUFBQSxFQUFzQjtBQUFBO0FBQUE7bUJBWXpCO0FBQUEsRUFLQztBQUFBO0FBQUEsSUFKQyxNQUFLO0FBQUEsSUFDTCxRQUFPO0FBQUEsSUFDUCxLQUFJO0FBQUE7RUFDSDtBQUFBLEVBQUk7QUFBQTtBQUFBO21CQUVQO0FBQUEsRUFFQztBQUFBO0FBQUEsSUFGRSxNQUFLO0FBQUEsSUFBaUMsUUFBTztBQUFBLElBQVMsS0FBSTtBQUFBO0VBQzFEO0FBQUEsRUFBTTtBQUFBO0FBQUE7bUJBR1Q7QUFBQSxFQUtDO0FBQUE7QUFBQSxJQUpDLE1BQUs7QUFBQSxJQUNMLFFBQU87QUFBQSxJQUNQLEtBQUk7QUFBQTtFQUNIO0FBQUEsRUFBSztBQUFBO0FBQUE7bUJBRVI7QUFBQSxFQUE0RTtBQUFBO0FBQUEsSUFBekUsTUFBSztBQUFBLElBQTBCLFFBQU87QUFBQSxJQUFTLEtBQUk7QUFBQTtFQUFXO0FBQUEsRUFBTztBQUFBO0FBQUE7bUJBRXhFO0FBQUEsRUFFQztBQUFBO0FBQUEsSUFGRSxNQUFLO0FBQUEsSUFBa0MsUUFBTztBQUFBLElBQVMsS0FBSTtBQUFBO0VBQzNEO0FBQUEsRUFBeUI7QUFBQTtBQUFBO21CQUc1QjtBQUFBLEVBQU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO21CQUU2QjtBQUFBLEVBQXNCO0FBQUE7QUFBQSxFQUFoQjtBQUFBLEVBQVM7QUFBQTtBQUFBO21CQVVsRDtBQUFBLEVBQTJFO0FBQUE7QUFBQSxJQUF4RSxNQUFLO0FBQUEsSUFBMkIsUUFBTztBQUFBLElBQVMsS0FBSTtBQUFBO0VBQVc7QUFBQSxFQUFLO0FBQUE7QUFBQTtvQkFDdkU7QUFBQSxFQUVDO0FBQUE7QUFBQSxJQUZFLE1BQUs7QUFBQSxJQUE0QixRQUFPO0FBQUEsSUFBUyxLQUFJO0FBQUE7RUFDckQ7QUFBQSxFQUFVO0FBQUE7QUFBQTtvQkFFYjtBQUFBLEVBRUM7QUFBQTtBQUFBLElBRkUsTUFBSztBQUFBLElBQWdDLFFBQU87QUFBQSxJQUFTLEtBQUk7QUFBQTtFQUN6RDtBQUFBLEVBQWM7QUFBQTtBQUFBO29CQUVqQjtBQUFBLEVBRUM7QUFBQTtBQUFBLElBRkUsTUFBSztBQUFBLElBQW9DLFFBQU87QUFBQSxJQUFTLEtBQUk7QUFBQTtFQUM3RDtBQUFBLEVBQWE7QUFBQTtBQUFBO29CQUVoQjtBQUFBLEVBS0M7QUFBQTtBQUFBLElBSkMsTUFBSztBQUFBLElBQ0wsUUFBTztBQUFBLElBQ1AsS0FBSTtBQUFBO0VBQ0g7QUFBQSxFQUFXO0FBQUE7QUFBQTtvQkFZZDtBQUFBLEVBQ0M7QUFBQTtBQUFBLElBREUsTUFBSztBQUFBLElBQXlCLFFBQU87QUFBQSxJQUFTLEtBQUk7QUFBQTtFQUFXO0FBQUEsRUFBUTtBQUFBO0FBQUE7b0JBRXhFO0FBQUEsRUFLQztBQUFBO0FBQUEsSUFKQyxNQUFLO0FBQUEsSUFDTCxRQUFPO0FBQUEsSUFDUCxLQUFJO0FBQUE7RUFDSDtBQUFBLEVBQWE7QUFBQTtBQUFBO29CQUVoQjtBQUFBLEVBRUM7QUFBQTtBQUFBLElBRkUsTUFBSztBQUFBLElBQXlCLFFBQU87QUFBQSxJQUFTLEtBQUk7QUFBQTtFQUNsRDtBQUFBLEVBQWdCO0FBQUE7QUFBQTtvQkFHbkI7QUFBQSxFQUVDO0FBQUE7QUFBQSxJQUZFLE1BQUs7QUFBQSxJQUE0QixRQUFPO0FBQUEsSUFBUyxLQUFJO0FBQUE7RUFDckQ7QUFBQSxFQUFNO0FBQUE7QUFBQTtvQkFhVDtBQUFBLEVBRUM7QUFBQTtBQUFBLElBRkUsTUFBSztBQUFBLElBQTZCLFFBQU87QUFBQSxJQUFTLEtBQUk7QUFBQTtFQUN0RDtBQUFBLEVBQWtCO0FBQUE7QUFBQTs7Ozs7O01BM0d2QixhQVdjO0FBQUEsUUFWRCxNQUFJLFNBQ2IsTUFBcUI7QUFBQSxVQUFyQixhQUFxQjtBQUFBO1FBRVosU0FBTyxTQUFDLE1BQWE7QUFBQSwyQkFBYixlQUFhO0FBQUE7MEJBQVcsTUFHM0M7QUFBQSwyQkFIMkMsY0FHM0M7QUFBQTtBQUFBLDJCQUVDLDhEQUVIO0FBQUE7Ozs7TUFFQSxhQWdDYztBQUFBLFFBL0JELE1BQUksU0FDYixNQUFlO0FBQUEsVUFBZixhQUFlO0FBQUE7UUFFTixTQUFPLFNBQUMsTUFBTztBQUFBLDJCQUFQLFNBQU87QUFBQTswQkFBVyxNQUdyQztBQUFBLDJCQUhxQywyQ0FHckM7QUFBQTtBQUFBLDJCQUtDLGlDQUNEO0FBQUE7QUFBQSwyQkFFQyxLQUVEO0FBQUE7QUFBQSwyQkFLQyxpRUFDRDtBQUFBO0FBQUEsMkJBQTRFLE9BRTVFO0FBQUE7QUFBQSwyQkFFQyxJQUVEO0FBQUE7QUFBQSwyQkFBTSxzQ0FFNkI7QUFBQTtBQUFBLDJCQUFzQixJQUMzRDtBQUFBOzs7O01BRUEsYUF3QmM7QUFBQSxRQXZCRCxNQUFJLFNBQ2IsTUFBaUI7QUFBQSxVQUFqQixhQUFpQjtBQUFBO1FBRVIsU0FBTyxTQUFDLE1BQVM7QUFBQSwyQkFBVCxXQUFTO0FBQUE7MEJBQVcsTUFHdkM7QUFBQSwyQkFIdUMsc0RBR3ZDO0FBQUE7QUFBQSwyQkFBMkUsSUFDM0U7QUFBQTtBQUFBLDJCQUVDLElBQ0Q7QUFBQTtBQUFBLDJCQUVDLFFBQ0Q7QUFBQTtBQUFBLDJCQUVDLGtEQUNEO0FBQUE7QUFBQSwyQkFLQyxZQUVIO0FBQUE7Ozs7TUFFQSxhQXVCYztBQUFBLFFBdEJELE1BQUksU0FDYixNQUFpQjtBQUFBLFVBQWpCLGFBQWlCO0FBQUE7UUFFUixTQUFPLFNBQUMsTUFBUztBQUFBLDJCQUFULFdBQVM7QUFBQTswQkFBVyxNQUd2QztBQUFBLDJCQUh1QyxtQ0FHdkM7QUFBQTtBQUFBLDJCQUNDLG9DQUNEO0FBQUE7QUFBQSwyQkFLQyxpQ0FDRDtBQUFBO0FBQUEsMkJBRUMsMkJBRUQ7QUFBQTtBQUFBLDJCQUVDLHFEQUVIO0FBQUE7Ozs7TUFFQSxhQVdjO0FBQUEsUUFWRCxNQUFJLFNBQ2IsTUFBZTtBQUFBLFVBQWYsYUFBZTtBQUFBO1FBRU4sU0FBTyxTQUFDLE1BQVc7QUFBQSwyQkFBWCxhQUFXO0FBQUE7MEJBQVcsTUFJekM7QUFBQSwyQkFKeUMseUdBSXpDO0FBQUE7QUFBQSwyQkFFQyxJQUNIO0FBQUEiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVGhlV2VsY29tZS52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cCBsYW5nPVwidHNcIj5cbmltcG9ydCBXZWxjb21lSXRlbSBmcm9tIFwiLi9XZWxjb21lSXRlbS52dWVcIjtcbmltcG9ydCBEb2N1bWVudGF0aW9uSWNvbiBmcm9tIFwiLi9pY29ucy9JY29uRG9jdW1lbnRhdGlvbi52dWVcIjtcbmltcG9ydCBUb29saW5nSWNvbiBmcm9tIFwiLi9pY29ucy9JY29uVG9vbGluZy52dWVcIjtcbmltcG9ydCBFY29zeXN0ZW1JY29uIGZyb20gXCIuL2ljb25zL0ljb25FY29zeXN0ZW0udnVlXCI7XG5pbXBvcnQgQ29tbXVuaXR5SWNvbiBmcm9tIFwiLi9pY29ucy9JY29uQ29tbXVuaXR5LnZ1ZVwiO1xuaW1wb3J0IFN1cHBvcnRJY29uIGZyb20gXCIuL2ljb25zL0ljb25TdXBwb3J0LnZ1ZVwiO1xuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cbiAgPFdlbGNvbWVJdGVtPlxuICAgIDx0ZW1wbGF0ZSAjaWNvbj5cbiAgICAgIDxEb2N1bWVudGF0aW9uSWNvbiAvPlxuICAgIDwvdGVtcGxhdGU+XG4gICAgPHRlbXBsYXRlICNoZWFkaW5nPkRvY3VtZW50YXRpb248L3RlbXBsYXRlPlxuXG4gICAgVnVl4oCZc1xuICAgIDxhIGhyZWY9XCJodHRwczovL3Z1ZWpzLm9yZy9cIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiXG4gICAgICA+b2ZmaWNpYWwgZG9jdW1lbnRhdGlvbjwvYVxuICAgID5cbiAgICBwcm92aWRlcyB5b3Ugd2l0aCBhbGwgaW5mb3JtYXRpb24geW91IG5lZWQgdG8gZ2V0IHN0YXJ0ZWQuXG4gIDwvV2VsY29tZUl0ZW0+XG5cbiAgPFdlbGNvbWVJdGVtPlxuICAgIDx0ZW1wbGF0ZSAjaWNvbj5cbiAgICAgIDxUb29saW5nSWNvbiAvPlxuICAgIDwvdGVtcGxhdGU+XG4gICAgPHRlbXBsYXRlICNoZWFkaW5nPlRvb2xpbmc8L3RlbXBsYXRlPlxuXG4gICAgVGhpcyBwcm9qZWN0IGlzIHNlcnZlZCBhbmQgYnVuZGxlZCB3aXRoXG4gICAgPGFcbiAgICAgIGhyZWY9XCJodHRwczovL3ZpdGVqcy5kZXYvZ3VpZGUvZmVhdHVyZXMuaHRtbFwiXG4gICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgcmVsPVwibm9vcGVuZXJcIlxuICAgICAgPlZpdGU8L2FcbiAgICA+LiBUaGUgcmVjb21tZW5kZWQgSURFIHNldHVwIGlzXG4gICAgPGEgaHJlZj1cImh0dHBzOi8vY29kZS52aXN1YWxzdHVkaW8uY29tL1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCJcbiAgICAgID5WU0NvZGU8L2FcbiAgICA+XG4gICAgK1xuICAgIDxhXG4gICAgICBocmVmPVwiaHR0cHM6Ly9naXRodWIuY29tL2pvaG5zb25jb2RlaGsvdm9sYXJcIlxuICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgIHJlbD1cIm5vb3BlbmVyXCJcbiAgICAgID5Wb2xhcjwvYVxuICAgID4uIElmIHlvdSBuZWVkIHRvIHRlc3QgeW91ciBjb21wb25lbnRzIGFuZCB3ZWIgcGFnZXMsIGNoZWNrIG91dFxuICAgIDxhIGhyZWY9XCJodHRwczovL3d3dy5jeXByZXNzLmlvL1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCI+Q3lwcmVzczwvYT5cbiAgICBhbmRcbiAgICA8YSBocmVmPVwiaHR0cHM6Ly9vbi5jeXByZXNzLmlvL2NvbXBvbmVudFwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCJcbiAgICAgID5DeXByZXNzIENvbXBvbmVudCBUZXN0aW5nPC9hXG4gICAgPi5cblxuICAgIDxiciAvPlxuXG4gICAgTW9yZSBpbnN0cnVjdGlvbnMgYXJlIGF2YWlsYWJsZSBpbiA8Y29kZT5SRUFETUUubWQ8L2NvZGU+LlxuICA8L1dlbGNvbWVJdGVtPlxuXG4gIDxXZWxjb21lSXRlbT5cbiAgICA8dGVtcGxhdGUgI2ljb24+XG4gICAgICA8RWNvc3lzdGVtSWNvbiAvPlxuICAgIDwvdGVtcGxhdGU+XG4gICAgPHRlbXBsYXRlICNoZWFkaW5nPkVjb3N5c3RlbTwvdGVtcGxhdGU+XG5cbiAgICBHZXQgb2ZmaWNpYWwgdG9vbHMgYW5kIGxpYnJhcmllcyBmb3IgeW91ciBwcm9qZWN0OlxuICAgIDxhIGhyZWY9XCJodHRwczovL3BpbmlhLnZ1ZWpzLm9yZy9cIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiPlBpbmlhPC9hPixcbiAgICA8YSBocmVmPVwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCJcbiAgICAgID5WdWUgUm91dGVyPC9hXG4gICAgPixcbiAgICA8YSBocmVmPVwiaHR0cHM6Ly90ZXN0LXV0aWxzLnZ1ZWpzLm9yZy9cIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiXG4gICAgICA+VnVlIFRlc3QgVXRpbHM8L2FcbiAgICA+LCBhbmRcbiAgICA8YSBocmVmPVwiaHR0cHM6Ly9naXRodWIuY29tL3Z1ZWpzL2RldnRvb2xzXCIgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXJcIlxuICAgICAgPlZ1ZSBEZXYgVG9vbHM8L2FcbiAgICA+LiBJZiB5b3UgbmVlZCBtb3JlIHJlc291cmNlcywgd2Ugc3VnZ2VzdCBwYXlpbmdcbiAgICA8YVxuICAgICAgaHJlZj1cImh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9hd2Vzb21lLXZ1ZVwiXG4gICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgcmVsPVwibm9vcGVuZXJcIlxuICAgICAgPkF3ZXNvbWUgVnVlPC9hXG4gICAgPlxuICAgIGEgdmlzaXQuXG4gIDwvV2VsY29tZUl0ZW0+XG5cbiAgPFdlbGNvbWVJdGVtPlxuICAgIDx0ZW1wbGF0ZSAjaWNvbj5cbiAgICAgIDxDb21tdW5pdHlJY29uIC8+XG4gICAgPC90ZW1wbGF0ZT5cbiAgICA8dGVtcGxhdGUgI2hlYWRpbmc+Q29tbXVuaXR5PC90ZW1wbGF0ZT5cblxuICAgIEdvdCBzdHVjaz8gQXNrIHlvdXIgcXVlc3Rpb24gb25cbiAgICA8YSBocmVmPVwiaHR0cHM6Ly9jaGF0LnZ1ZWpzLm9yZ1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCI+VnVlIExhbmQ8L2FcbiAgICA+LCBvdXIgb2ZmaWNpYWwgRGlzY29yZCBzZXJ2ZXIsIG9yXG4gICAgPGFcbiAgICAgIGhyZWY9XCJodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy90YWdnZWQvdnVlLmpzXCJcbiAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICByZWw9XCJub29wZW5lclwiXG4gICAgICA+U3RhY2tPdmVyZmxvdzwvYVxuICAgID4uIFlvdSBzaG91bGQgYWxzbyBzdWJzY3JpYmUgdG9cbiAgICA8YSBocmVmPVwiaHR0cHM6Ly9uZXdzLnZ1ZWpzLm9yZ1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCJcbiAgICAgID5vdXIgbWFpbGluZyBsaXN0PC9hXG4gICAgPlxuICAgIGFuZCBmb2xsb3cgdGhlIG9mZmljaWFsXG4gICAgPGEgaHJlZj1cImh0dHBzOi8vdHdpdHRlci5jb20vdnVlanNcIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiXG4gICAgICA+QHZ1ZWpzPC9hXG4gICAgPlxuICAgIHR3aXR0ZXIgYWNjb3VudCBmb3IgbGF0ZXN0IG5ld3MgaW4gdGhlIFZ1ZSB3b3JsZC5cbiAgPC9XZWxjb21lSXRlbT5cblxuICA8V2VsY29tZUl0ZW0+XG4gICAgPHRlbXBsYXRlICNpY29uPlxuICAgICAgPFN1cHBvcnRJY29uIC8+XG4gICAgPC90ZW1wbGF0ZT5cbiAgICA8dGVtcGxhdGUgI2hlYWRpbmc+U3VwcG9ydCBWdWU8L3RlbXBsYXRlPlxuXG4gICAgQXMgYW4gaW5kZXBlbmRlbnQgcHJvamVjdCwgVnVlIHJlbGllcyBvbiBjb21tdW5pdHkgYmFja2luZyBmb3IgaXRzXG4gICAgc3VzdGFpbmFiaWxpdHkuIFlvdSBjYW4gaGVscCB1cyBieVxuICAgIDxhIGhyZWY9XCJodHRwczovL3Z1ZWpzLm9yZy9zcG9uc29yL1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCJcbiAgICAgID5iZWNvbWluZyBhIHNwb25zb3I8L2FcbiAgICA+LlxuICA8L1dlbGNvbWVJdGVtPlxuPC90ZW1wbGF0ZT5cbiJdLCJmaWxlIjoiL1VzZXJzL3NhcmFyZWdhbi9Db2RlL2Nvc21pYy1kb3VnaG51dC9zcmMvY29tcG9uZW50cy9UaGVXZWxjb21lLnZ1ZSJ9