import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/icons/IconSupport.vue");const _sfc_main = {}
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=bc0fccca"

const _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "20",
  height: "20",
  fill: "currentColor"
}
const _hoisted_2 = /*#__PURE__*/_createElementVNode("path", { d: "M10 3.22l-.61-.6a5.5 5.5 0 0 0-7.666.105 5.5 5.5 0 0 0-.114 7.665L10 18.78l8.39-8.4a5.5 5.5 0 0 0-.114-7.665 5.5 5.5 0 0 0-7.666-.105l-.61.61z" }, null, -1 /* HOISTED */)
const _hoisted_3 = [
  _hoisted_2
]

function _sfc_render(_ctx, _cache) {
  return (_openBlock(), _createElementBlock("svg", _hoisted_1, _hoisted_3))
}


_sfc_main.__hmrId = "4ddc0cb9"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"/Users/sararegan/Code/cosmic-doughnut/src/components/icons/IconSupport.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkljb25TdXBwb3J0LnZ1ZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7RUFFSSxLQUFLLEVBQUMsNEJBQTRCO0VBQ2xDLEtBQUssRUFBQyxJQUFJO0VBQ1YsTUFBTSxFQUFDLElBQUk7RUFDWCxJQUFJLEVBQUMsY0FBYzs7Z0NBRW5CLG9CQUVFLFVBREEsQ0FBQyxFQUFDLGdKQUFnSjs7RUFEcEosVUFFRTs7Ozt3QkFSSixvQkFTTSxPQVROLFVBU00iLCJmaWxlIjoiL1VzZXJzL3NhcmFyZWdhbi9Db2RlL2Nvc21pYy1kb3VnaG51dC9zcmMvY29tcG9uZW50cy9pY29ucy9JY29uU3VwcG9ydC52dWUiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxuICA8c3ZnXG4gICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgd2lkdGg9XCIyMFwiXG4gICAgaGVpZ2h0PVwiMjBcIlxuICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxuICA+XG4gICAgPHBhdGhcbiAgICAgIGQ9XCJNMTAgMy4yMmwtLjYxLS42YTUuNSA1LjUgMCAwIDAtNy42NjYuMTA1IDUuNSA1LjUgMCAwIDAtLjExNCA3LjY2NUwxMCAxOC43OGw4LjM5LTguNGE1LjUgNS41IDAgMCAwLS4xMTQtNy42NjUgNS41IDUuNSAwIDAgMC03LjY2Ni0uMTA1bC0uNjEuNjF6XCJcbiAgICAvPlxuICA8L3N2Zz5cbjwvdGVtcGxhdGU+XG4iXX0=