import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HelloWorld.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=bc0fccca";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "HelloWorld",
  props: {
    msg: { type: String, required: true }
  },
  setup(__props, { expose: __expose }) {
    __expose();
    const __returned__ = {};
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { toDisplayString as _toDisplayString, createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, pushScopeId as _pushScopeId, popScopeId as _popScopeId } from "/node_modules/.vite/deps/vue.js?v=bc0fccca";
const _withScopeId = (n) => (_pushScopeId("data-v-e17ea971"), n = n(), _popScopeId(), n);
const _hoisted_1 = { class: "greetings" };
const _hoisted_2 = { class: "green" };
const _hoisted_3 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ _createElementVNode(
  "h3",
  null,
  [
    /* @__PURE__ */ _createTextVNode(" You\u2019ve successfully created a project with "),
    /* @__PURE__ */ _createElementVNode("a", {
      href: "https://vitejs.dev/",
      target: "_blank",
      rel: "noopener"
    }, "Vite"),
    /* @__PURE__ */ _createTextVNode(" + "),
    /* @__PURE__ */ _createElementVNode("a", {
      href: "https://vuejs.org/",
      target: "_blank",
      rel: "noopener"
    }, "Vue 3"),
    /* @__PURE__ */ _createTextVNode(". What's next? ")
  ],
  -1
  /* HOISTED */
));
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return _openBlock(), _createElementBlock("div", _hoisted_1, [
    _createElementVNode(
      "h1",
      _hoisted_2,
      _toDisplayString($props.msg),
      1
      /* TEXT */
    ),
    _hoisted_3
  ]);
}
import "/src/components/HelloWorld.vue?vue&type=style&index=0&scoped=e17ea971&lang.css";
_sfc_main.__hmrId = "e17ea971";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-e17ea971"], ["__file", "/Users/sararegan/Code/cosmic-doughnut/src/components/HelloWorld.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O3FCQU9PLE9BQU0sWUFBVztxQkFDaEIsT0FBTSxRQUFPO3NEQUNqQjtBQUFBLEVBS0s7QUFBQTtBQUFBO0FBQUEscUNBTEQsbURBRUY7QUFBQSx3Q0FBcUU7QUFBQSxNQUFsRSxNQUFLO0FBQUEsTUFBc0IsUUFBTztBQUFBLE1BQVMsS0FBSTtBQUFBLE9BQVcsTUFBSTtBQUFBLHFDQUFJLEtBQ3JFO0FBQUEsd0NBQXFFO0FBQUEsTUFBbEUsTUFBSztBQUFBLE1BQXFCLFFBQU87QUFBQSxNQUFTLEtBQUk7QUFBQSxPQUFXLE9BQUs7QUFBQSxxQ0FBSSxpQkFFdkU7QUFBQTs7Ozs7dUJBUEYsb0JBUU0sT0FSTixZQVFNO0FBQUEsSUFQSjtBQUFBLE1BQWdDO0FBQUEsTUFBaEM7QUFBQSxNQUFnQyxpQkFBWCxVQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFDeEI7QUFBQSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIZWxsb1dvcmxkLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwIGxhbmc9XCJ0c1wiPlxuZGVmaW5lUHJvcHM8e1xuICBtc2c6IHN0cmluZztcbn0+KCk7XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8ZGl2IGNsYXNzPVwiZ3JlZXRpbmdzXCI+XG4gICAgPGgxIGNsYXNzPVwiZ3JlZW5cIj57eyBtc2cgfX08L2gxPlxuICAgIDxoMz5cbiAgICAgIFlvdeKAmXZlIHN1Y2Nlc3NmdWxseSBjcmVhdGVkIGEgcHJvamVjdCB3aXRoXG4gICAgICA8YSBocmVmPVwiaHR0cHM6Ly92aXRlanMuZGV2L1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCI+Vml0ZTwvYT4gK1xuICAgICAgPGEgaHJlZj1cImh0dHBzOi8vdnVlanMub3JnL1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCI+VnVlIDM8L2E+LlxuICAgICAgV2hhdCdzIG5leHQ/XG4gICAgPC9oMz5cbiAgPC9kaXY+XG48L3RlbXBsYXRlPlxuXG48c3R5bGUgc2NvcGVkPlxuaDEge1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXNpemU6IDIuNnJlbTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IC0xMHB4O1xufVxuXG5oMyB7XG4gIGZvbnQtc2l6ZTogMS4ycmVtO1xufVxuXG4uZ3JlZXRpbmdzIGgxLFxuLmdyZWV0aW5ncyBoMyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDEwMjRweCkge1xuICAuZ3JlZXRpbmdzIGgxLFxuICAuZ3JlZXRpbmdzIGgzIHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICB9XG59XG48L3N0eWxlPlxuIl0sImZpbGUiOiIvVXNlcnMvc2FyYXJlZ2FuL0NvZGUvY29zbWljLWRvdWdobnV0L3NyYy9jb21wb25lbnRzL0hlbGxvV29ybGQudnVlIn0=