import.meta.env = {"BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { createRouter, createWebHistory } from "/node_modules/.vite/deps/vue-router.js?v=bc0fccca";
import HomeView from "/src/views/HomeView.vue";
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: HomeView
    },
    {
      path: "/about",
      name: "about",
      // route level code-splitting
      // this generates a separate chunk (About.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import("/src/views/AboutView.vue")
    }
  ]
});
export default router;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZVJvdXRlciwgY3JlYXRlV2ViSGlzdG9yeSB9IGZyb20gXCJ2dWUtcm91dGVyXCI7XG5pbXBvcnQgSG9tZVZpZXcgZnJvbSBcIi4uL3ZpZXdzL0hvbWVWaWV3LnZ1ZVwiO1xuXG5jb25zdCByb3V0ZXIgPSBjcmVhdGVSb3V0ZXIoe1xuICBoaXN0b3J5OiBjcmVhdGVXZWJIaXN0b3J5KGltcG9ydC5tZXRhLmVudi5CQVNFX1VSTCksXG4gIHJvdXRlczogW1xuICAgIHtcbiAgICAgIHBhdGg6IFwiL1wiLFxuICAgICAgbmFtZTogXCJob21lXCIsXG4gICAgICBjb21wb25lbnQ6IEhvbWVWaWV3LFxuICAgIH0sXG4gICAge1xuICAgICAgcGF0aDogXCIvYWJvdXRcIixcbiAgICAgIG5hbWU6IFwiYWJvdXRcIixcbiAgICAgIC8vIHJvdXRlIGxldmVsIGNvZGUtc3BsaXR0aW5nXG4gICAgICAvLyB0aGlzIGdlbmVyYXRlcyBhIHNlcGFyYXRlIGNodW5rIChBYm91dC5baGFzaF0uanMpIGZvciB0aGlzIHJvdXRlXG4gICAgICAvLyB3aGljaCBpcyBsYXp5LWxvYWRlZCB3aGVuIHRoZSByb3V0ZSBpcyB2aXNpdGVkLlxuICAgICAgY29tcG9uZW50OiAoKSA9PiBpbXBvcnQoXCIuLi92aWV3cy9BYm91dFZpZXcudnVlXCIpLFxuICAgIH0sXG4gIF0sXG59KTtcblxuZXhwb3J0IGRlZmF1bHQgcm91dGVyO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGNBQWMsd0JBQXdCO0FBQy9DLE9BQU8sY0FBYztBQUVyQixNQUFNLFNBQVMsYUFBYTtBQUFBLEVBQzFCLFNBQVMsaUJBQWlCLFlBQVksSUFBSSxRQUFRO0FBQUEsRUFDbEQsUUFBUTtBQUFBLElBQ047QUFBQSxNQUNFLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLFdBQVc7QUFBQSxJQUNiO0FBQUEsSUFDQTtBQUFBLE1BQ0UsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSU4sV0FBVyxNQUFNLE9BQU8sd0JBQXdCO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUVELGVBQWU7IiwibmFtZXMiOltdfQ==