import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/icons/IconCommunity.vue");const _sfc_main = {}
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=bc0fccca"

const _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "20",
  height: "20",
  fill: "currentColor"
}
const _hoisted_2 = /*#__PURE__*/_createElementVNode("path", { d: "M15 4a1 1 0 1 0 0 2V4zm0 11v-1a1 1 0 0 0-1 1h1zm0 4l-.707.707A1 1 0 0 0 16 19h-1zm-4-4l.707-.707A1 1 0 0 0 11 14v1zm-4.707-1.293a1 1 0 0 0-1.414 1.414l1.414-1.414zm-.707.707l-.707-.707.707.707zM9 11v-1a1 1 0 0 0-.707.293L9 11zm-4 0h1a1 1 0 0 0-1-1v1zm0 4H4a1 1 0 0 0 1.707.707L5 15zm10-9h2V4h-2v2zm2 0a1 1 0 0 1 1 1h2a3 3 0 0 0-3-3v2zm1 1v6h2V7h-2zm0 6a1 1 0 0 1-1 1v2a3 3 0 0 0 3-3h-2zm-1 1h-2v2h2v-2zm-3 1v4h2v-4h-2zm1.707 3.293l-4-4-1.414 1.414 4 4 1.414-1.414zM11 14H7v2h4v-2zm-4 0c-.276 0-.525-.111-.707-.293l-1.414 1.414C5.42 15.663 6.172 16 7 16v-2zm-.707 1.121l3.414-3.414-1.414-1.414-3.414 3.414 1.414 1.414zM9 12h4v-2H9v2zm4 0a3 3 0 0 0 3-3h-2a1 1 0 0 1-1 1v2zm3-3V3h-2v6h2zm0-6a3 3 0 0 0-3-3v2a1 1 0 0 1 1 1h2zm-3-3H3v2h10V0zM3 0a3 3 0 0 0-3 3h2a1 1 0 0 1 1-1V0zM0 3v6h2V3H0zm0 6a3 3 0 0 0 3 3v-2a1 1 0 0 1-1-1H0zm3 3h2v-2H3v2zm1-1v4h2v-4H4zm1.707 4.707l.586-.586-1.414-1.414-.586.586 1.414 1.414z" }, null, -1 /* HOISTED */)
const _hoisted_3 = [
  _hoisted_2
]

function _sfc_render(_ctx, _cache) {
  return (_openBlock(), _createElementBlock("svg", _hoisted_1, _hoisted_3))
}


_sfc_main.__hmrId = "e1b50a75"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"/Users/sararegan/Code/cosmic-doughnut/src/components/icons/IconCommunity.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkljb25Db21tdW5pdHkudnVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztFQUVJLEtBQUssRUFBQyw0QkFBNEI7RUFDbEMsS0FBSyxFQUFDLElBQUk7RUFDVixNQUFNLEVBQUMsSUFBSTtFQUNYLElBQUksRUFBQyxjQUFjOztnQ0FFbkIsb0JBRUUsVUFEQSxDQUFDLEVBQUMsODRCQUE4NEI7O0VBRGw1QixVQUVFOzs7O3dCQVJKLG9CQVNNLE9BVE4sVUFTTSIsImZpbGUiOiIvVXNlcnMvc2FyYXJlZ2FuL0NvZGUvY29zbWljLWRvdWdobnV0L3NyYy9jb21wb25lbnRzL2ljb25zL0ljb25Db21tdW5pdHkudnVlIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cbiAgPHN2Z1xuICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgIHdpZHRoPVwiMjBcIlxuICAgIGhlaWdodD1cIjIwXCJcbiAgICBmaWxsPVwiY3VycmVudENvbG9yXCJcbiAgPlxuICAgIDxwYXRoXG4gICAgICBkPVwiTTE1IDRhMSAxIDAgMSAwIDAgMlY0em0wIDExdi0xYTEgMSAwIDAgMC0xIDFoMXptMCA0bC0uNzA3LjcwN0ExIDEgMCAwIDAgMTYgMTloLTF6bS00LTRsLjcwNy0uNzA3QTEgMSAwIDAgMCAxMSAxNHYxem0tNC43MDctMS4yOTNhMSAxIDAgMCAwLTEuNDE0IDEuNDE0bDEuNDE0LTEuNDE0em0tLjcwNy43MDdsLS43MDctLjcwNy43MDcuNzA3ek05IDExdi0xYTEgMSAwIDAgMC0uNzA3LjI5M0w5IDExem0tNCAwaDFhMSAxIDAgMCAwLTEtMXYxem0wIDRINGExIDEgMCAwIDAgMS43MDcuNzA3TDUgMTV6bTEwLTloMlY0aC0ydjJ6bTIgMGExIDEgMCAwIDEgMSAxaDJhMyAzIDAgMCAwLTMtM3Yyem0xIDF2NmgyVjdoLTJ6bTAgNmExIDEgMCAwIDEtMSAxdjJhMyAzIDAgMCAwIDMtM2gtMnptLTEgMWgtMnYyaDJ2LTJ6bS0zIDF2NGgydi00aC0yem0xLjcwNyAzLjI5M2wtNC00LTEuNDE0IDEuNDE0IDQgNCAxLjQxNC0xLjQxNHpNMTEgMTRIN3YyaDR2LTJ6bS00IDBjLS4yNzYgMC0uNTI1LS4xMTEtLjcwNy0uMjkzbC0xLjQxNCAxLjQxNEM1LjQyIDE1LjY2MyA2LjE3MiAxNiA3IDE2di0yem0tLjcwNyAxLjEyMWwzLjQxNC0zLjQxNC0xLjQxNC0xLjQxNC0zLjQxNCAzLjQxNCAxLjQxNCAxLjQxNHpNOSAxMmg0di0ySDl2MnptNCAwYTMgMyAwIDAgMCAzLTNoLTJhMSAxIDAgMCAxLTEgMXYyem0zLTNWM2gtMnY2aDJ6bTAtNmEzIDMgMCAwIDAtMy0zdjJhMSAxIDAgMCAxIDEgMWgyem0tMy0zSDN2MmgxMFYwek0zIDBhMyAzIDAgMCAwLTMgM2gyYTEgMSAwIDAgMSAxLTFWMHpNMCAzdjZoMlYzSDB6bTAgNmEzIDMgMCAwIDAgMyAzdi0yYTEgMSAwIDAgMS0xLTFIMHptMyAzaDJ2LTJIM3Yyem0xLTF2NGgydi00SDR6bTEuNzA3IDQuNzA3bC41ODYtLjU4Ni0xLjQxNC0xLjQxNC0uNTg2LjU4NiAxLjQxNCAxLjQxNHpcIlxuICAgIC8+XG4gIDwvc3ZnPlxuPC90ZW1wbGF0ZT5cbiJdfQ==