import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=bc0fccca";
import { RouterLink, RouterView } from "/node_modules/.vite/deps/vue-router.js?v=bc0fccca";
import HelloWorld from "/src/components/HelloWorld.vue";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "App",
  setup(__props, { expose: __expose }) {
    __expose();
    const __returned__ = { get RouterLink() {
      return RouterLink;
    }, get RouterView() {
      return RouterView;
    }, HelloWorld };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { createElementVNode as _createElementVNode, createVNode as _createVNode, createTextVNode as _createTextVNode, withCtx as _withCtx, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, pushScopeId as _pushScopeId, popScopeId as _popScopeId } from "/node_modules/.vite/deps/vue.js?v=bc0fccca";
import _imports_0 from "/src/assets/logo.svg?import";
const _withScopeId = (n) => (_pushScopeId("data-v-7a7a37b1"), n = n(), _popScopeId(), n);
const _hoisted_1 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ _createElementVNode(
  "img",
  {
    alt: "Vue logo",
    class: "logo",
    src: _imports_0,
    width: "125",
    height: "125"
  },
  null,
  -1
  /* HOISTED */
));
const _hoisted_2 = { class: "wrapper" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return _openBlock(), _createElementBlock(
    _Fragment,
    null,
    [
      _createElementVNode("header", null, [
        _hoisted_1,
        _createElementVNode("div", _hoisted_2, [
          _createVNode($setup["HelloWorld"], { msg: "You did it!" }),
          _createElementVNode("nav", null, [
            _createVNode($setup["RouterLink"], { to: "/" }, {
              default: _withCtx(() => [
                _createTextVNode("Home")
              ]),
              _: 1
              /* STABLE */
            }),
            _createVNode($setup["RouterLink"], { to: "/about" }, {
              default: _withCtx(() => [
                _createTextVNode("About")
              ]),
              _: 1
              /* STABLE */
            })
          ])
        ])
      ]),
      _createVNode($setup["RouterView"])
    ],
    64
    /* STABLE_FRAGMENT */
  );
}
import "/src/App.vue?vue&type=style&index=0&scoped=7a7a37b1&lang.css";
_sfc_main.__hmrId = "7a7a37b1";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-7a7a37b1"], ["__file", "/Users/sararegan/Code/cosmic-doughnut/src/App.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQVMsWUFBWSxrQkFBa0I7QUFDdkMsT0FBTyxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7OztPQVFqQixnQkFBdUI7O3NEQUh6QjtBQUFBLEVBTUU7QUFBQTtBQUFBLElBTEEsS0FBSTtBQUFBLElBQ0osT0FBTTtBQUFBLElBQ047QUFBQSxJQUNBLE9BQU07QUFBQSxJQUNOLFFBQU87QUFBQTs7Ozs7cUJBR0osT0FBTSxVQUFTOzs7Ozs7TUFUdEIsb0JBaUJTO0FBQUEsUUFoQlA7QUFBQSxRQVFBLG9CQU9NLE9BUE4sWUFPTTtBQUFBLFVBTkosYUFBZ0Msd0JBQXBCLEtBQUksY0FBYTtBQUFBLFVBRTdCLG9CQUdNO0FBQUEsWUFGSixhQUFvQyx3QkFBeEIsSUFBRyxJQUFHO0FBQUEsZ0NBQUMsTUFBSTtBQUFBLGlDQUFKLE1BQUk7QUFBQTs7OztZQUN2QixhQUEwQyx3QkFBOUIsSUFBRyxTQUFRO0FBQUEsZ0NBQUMsTUFBSztBQUFBLGlDQUFMLE9BQUs7QUFBQTs7Ozs7OztNQUtuQyxhQUFjO0FBQUEiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwIGxhbmc9XCJ0c1wiPlxuaW1wb3J0IHsgUm91dGVyTGluaywgUm91dGVyVmlldyB9IGZyb20gXCJ2dWUtcm91dGVyXCI7XG5pbXBvcnQgSGVsbG9Xb3JsZCBmcm9tIFwiLi9jb21wb25lbnRzL0hlbGxvV29ybGQudnVlXCI7XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8aGVhZGVyPlxuICAgIDxpbWdcbiAgICAgIGFsdD1cIlZ1ZSBsb2dvXCJcbiAgICAgIGNsYXNzPVwibG9nb1wiXG4gICAgICBzcmM9XCJAL2Fzc2V0cy9sb2dvLnN2Z1wiXG4gICAgICB3aWR0aD1cIjEyNVwiXG4gICAgICBoZWlnaHQ9XCIxMjVcIlxuICAgIC8+XG5cbiAgICA8ZGl2IGNsYXNzPVwid3JhcHBlclwiPlxuICAgICAgPEhlbGxvV29ybGQgbXNnPVwiWW91IGRpZCBpdCFcIiAvPlxuXG4gICAgICA8bmF2PlxuICAgICAgICA8Um91dGVyTGluayB0bz1cIi9cIj5Ib21lPC9Sb3V0ZXJMaW5rPlxuICAgICAgICA8Um91dGVyTGluayB0bz1cIi9hYm91dFwiPkFib3V0PC9Sb3V0ZXJMaW5rPlxuICAgICAgPC9uYXY+XG4gICAgPC9kaXY+XG4gIDwvaGVhZGVyPlxuXG4gIDxSb3V0ZXJWaWV3IC8+XG48L3RlbXBsYXRlPlxuXG48c3R5bGUgc2NvcGVkPlxuaGVhZGVyIHtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgbWF4LWhlaWdodDogMTAwdmg7XG59XG5cbi5sb2dvIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogMCBhdXRvIDJyZW07XG59XG5cbm5hdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDEycHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogMnJlbTtcbn1cblxubmF2IGEucm91dGVyLWxpbmstZXhhY3QtYWN0aXZlIHtcbiAgY29sb3I6IHZhcigtLWNvbG9yLXRleHQpO1xufVxuXG5uYXYgYS5yb3V0ZXItbGluay1leGFjdC1hY3RpdmU6aG92ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxubmF2IGEge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBhZGRpbmc6IDAgMXJlbTtcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCB2YXIoLS1jb2xvci1ib3JkZXIpO1xufVxuXG5uYXYgYTpmaXJzdC1vZi10eXBlIHtcbiAgYm9yZGVyOiAwO1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogMTAyNHB4KSB7XG4gIGhlYWRlciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBwbGFjZS1pdGVtczogY2VudGVyO1xuICAgIHBhZGRpbmctcmlnaHQ6IGNhbGModmFyKC0tc2VjdGlvbi1nYXApIC8gMik7XG4gIH1cblxuICAubG9nbyB7XG4gICAgbWFyZ2luOiAwIDJyZW0gMCAwO1xuICB9XG5cbiAgaGVhZGVyIC53cmFwcGVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHBsYWNlLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICAgIGZsZXgtd3JhcDogd3JhcDtcbiAgfVxuXG4gIG5hdiB7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBtYXJnaW4tbGVmdDogLTFyZW07XG4gICAgZm9udC1zaXplOiAxcmVtO1xuXG4gICAgcGFkZGluZzogMXJlbSAwO1xuICAgIG1hcmdpbi10b3A6IDFyZW07XG4gIH1cbn1cbjwvc3R5bGU+XG4iXSwiZmlsZSI6Ii9Vc2Vycy9zYXJhcmVnYW4vQ29kZS9jb3NtaWMtZG91Z2hudXQvc3JjL0FwcC52dWUifQ==