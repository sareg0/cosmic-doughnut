import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HelloWorld.vue?vue&type=style&index=0&scoped=e17ea971&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/sararegan/Code/cosmic-doughnut/src/components/HelloWorld.vue?vue&type=style&index=0&scoped=e17ea971&lang.css"
const __vite__css = "\nh1[data-v-e17ea971] {\n  font-weight: 500;\n  font-size: 2.6rem;\n  position: relative;\n  top: -10px;\n}\nh3[data-v-e17ea971] {\n  font-size: 1.2rem;\n}\n.greetings h1[data-v-e17ea971],\n.greetings h3[data-v-e17ea971] {\n  text-align: center;\n}\n@media (min-width: 1024px) {\n.greetings h1[data-v-e17ea971],\n  .greetings h3[data-v-e17ea971] {\n    text-align: left;\n}\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))